

import UIKit

class ToDoListTableViewController: UITableViewController {

    var toDoItems = [ToDoItem]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.leftBarButtonItem = editButtonItem()
        
        if let savedToDoItems = loadToDoItems() {
            toDoItems = savedToDoItems
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func setEditing(editing:Bool, animated:Bool)
    {
        super.setEditing(editing,animated:animated)
        if (self.editing) {
            self.editButtonItem().title = "Hotovo"
        }
        else {
            self.editButtonItem().title = "Zmazať úlohu"
        }
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.toDoItems.count
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cellIdentifier = "ToDoItemTableViewCell"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as! ToDoItemTableViewCell
        let toDoItem = toDoItems[indexPath.row]
        
        cell.nameLabel.text = toDoItem.name
        cell.photoImageView.image = toDoItem.photo
        
        self.tableView.rowHeight = 90.0
        
        return cell
    }



    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            toDoItems.removeAtIndex(indexPath.row)
            saveToDoItems()
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
        }
    }


    
    // MARK: - Navigation

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "ShowDetail" {
            let ToDoItemDetailViewController = segue.destinationViewController as! AddToDoItemViewController
            if let selectedToDoItemCell = sender as? ToDoItemTableViewCell {
                let indexPath = tableView.indexPathForCell(selectedToDoItemCell)!
                let selectedToDoItem = toDoItems[indexPath.row]
                ToDoItemDetailViewController.toDoItem = selectedToDoItem
            }
        }
        else if segue.identifier == "AddItem" {
            print("Adding new To-Do Item.")
        }
    }
    
    
    @IBAction func unwindToList(sender: UIStoryboardSegue) {
        if let sourceViewController = sender.sourceViewController as? AddToDoItemViewController, toDoItem = sourceViewController.toDoItem {
            if let selectedIndexPath = tableView.indexPathForSelectedRow {

                toDoItems[selectedIndexPath.row] = toDoItem
                tableView.reloadRowsAtIndexPaths([selectedIndexPath], withRowAnimation: .None)
            }
            else {

                let newIndexPath = NSIndexPath(forRow: toDoItems.count, inSection: 0)
                toDoItems.append(toDoItem)
                tableView.insertRowsAtIndexPaths([newIndexPath], withRowAnimation: .Bottom)
            }

            saveToDoItems()
        }
    }
    
    // MARK: NSCoding
    func saveToDoItems() {
        let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(toDoItems, toFile: ToDoItem.ArchiveURL.path!)
        if !isSuccessfulSave {
            print("Failed to save ToDoItems...")
        }
    }
    
    func loadToDoItems() -> [ToDoItem]? {
        return NSKeyedUnarchiver.unarchiveObjectWithFile(ToDoItem.ArchiveURL.path!) as? [ToDoItem]
    }
}
