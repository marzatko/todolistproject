

import UIKit

class AddToDoItemViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    //MARK: Properties
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var saveButton: UIBarButtonItem!
    @IBOutlet weak var photoImageView: UIImageView!
    
    
    var toDoItem: ToDoItem?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        textField.delegate = self
        
        if let toDoItem = toDoItem {
            navigationItem.title = toDoItem.name
            textField.text   = toDoItem.name
            photoImageView.image = toDoItem.photo
        }
        

        checkValidMealName()
    }
    
    // MARK: UITextFieldDelegate
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    func textFieldDidEndEditing(textField: UITextField) {
        checkValidMealName()
        navigationItem.title = textField.text
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        saveButton.enabled = false
    }
    
    func checkValidMealName() {
        let text = textField.text ?? ""
        saveButton.enabled = !text.isEmpty
    }



// TOTO pôjde preč, či? nechať, ak by to robilo problém, potom preč

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: UIImagePickerControllerDelegate
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        let selectedImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        photoImageView.image = selectedImage
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    // MARK: Navigation
    @IBAction func cancel(sender: UIBarButtonItem) {
        let isPresentingInAddToDoItemMode = presentingViewController is UINavigationController
        
        if isPresentingInAddToDoItemMode {
            dismissViewControllerAnimated(true, completion: nil)
        }
        else {
            navigationController!.popViewControllerAnimated(true)
        }
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if saveButton === sender {
            let name = textField.text ?? ""
            let photo = photoImageView.image
            
            toDoItem = ToDoItem(name: name, photo: photo)
        }
    }
    
    // MARK: Action
    @IBAction func selectImageFromPhotoLibrary(sender: UITapGestureRecognizer) {
        textField.resignFirstResponder()
        let imagePickerController = UIImagePickerController()
        imagePickerController.sourceType = .PhotoLibrary
        imagePickerController.delegate = self
        presentViewController(imagePickerController, animated: true, completion: nil)
    }

    @IBAction func doneButton(sender: UIButton) {
        if NSString(string: textField.text!).containsString("✅ ") {
        } else {
            textField.text = "✅ " + textField.text!
        }
    }
    
    @IBAction func undoneButton(sender: UIButton) {
        if NSString(string: textField.text!).containsString("✅ ") {
            textField.text = textField.text!.stringByReplacingOccurrencesOfString("✅ ", withString: "")
        }
    }

}
